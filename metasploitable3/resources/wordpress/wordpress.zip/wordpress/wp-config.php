<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '@?FmT&ouV>E*ewlU/+^zSaLho=}qI`luZ5d$WNy_GU($^{@D&T:LG*)fMZjRog&{');
define('SECURE_AUTH_KEY',  'f:{OGNAj-H1Cp0h 0LC8v@wx$Z4%C)oUXpq$dC@`Qr{5/;r`t|Cy8.3N$SseLlVd');
define('LOGGED_IN_KEY',    '~RrV)Vczu}#VNiWwJq$s}[7J>gB#3GE(ZtuWm|Qea+lZ)hse~stP~.B@xYui>{%q');
define('NONCE_KEY',        'GPh]GLXqi[z&mralkItzn=H&#(Z?<blSZ1Y7<tcQor:z4z 2H[f{PJR0#iz v%gK');
define('AUTH_SALT',        'UMb|`KU:Eys4j)`F+svcr1@KifSy{~3}]#$dA^!?x6pe]Qfl$+!!1P)w^D}jw4=/');
define('SECURE_AUTH_SALT', 'fjGU23)|ZDGW=8ohS1~r=s:$(ff@>n>:p$+Wk@V;+J6W9&{dCu&?=ZM.k,No@PPd');
define('LOGGED_IN_SALT',   '@N.u3x$fz$%ppS*?;}t>_Xvv~iFVIC<X%8X!VBT9~UWYORKJ#M<G$ bG:F5Y@:c(');
define('NONCE_SALT',       ']|24lfp7Ud*.pZz?F>Ozos^!g^$IJp`0~0,(Vi+cx((ly7IUhh(m=Gx4M(h2%dWc');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
